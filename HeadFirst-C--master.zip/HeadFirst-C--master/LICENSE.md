This is the solution of dog race lab. in HeadFirst C#.

